# Core Developers

----------
- [@sepandhaghighi](http://github.com/sepandhaghighi) - Open Science Laboratory
- [@sadrasabouri](https://github.com/sadrasabouri) - Open Science Laboratory

# Other Contributors
----------
- [@heidecjj](https://github.com/heidecjj)
- [@noobkoder](https://github.com/n00bkoder)
- [@codewithnick](https://github.com/codewithnick)
- [@eumiro](https://github.com/eumiro)
